#
# SPDX-FileCopyrightText: Copyright (c) 2024-2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

import os
import platform
from enum import Enum
from collections import namedtuple
from urllib.parse import urlparse
from ._pydeepstream import Receiver, BufferRetriever, Feeder, BatchMetadataOperator, Tensor, Probe, PreprocessBatchUserMetadata, CommonFactory, signal
from .pipeline import Pipeline
from .source_config import SourceConfig, SmartRecordConfig
from typing import Callable, Optional
from dataclasses import dataclass

class RenderMode(Enum):
    DISPLAY = 1
    DISCARD = 2
    STREAM = 3


StreamInfo = namedtuple("StreamInfo", ['originator', 'template'])

_mime_table = {
    "JPEG": "image/jpeg",
    "PNG": "image/png",
    "RGB": "video/x-raw",
    "RGBA": "video/x-raw",
    "I420": "video/x-raw"
}

def _populate_kwargs(properties, **kwargs):
    for key, value in kwargs.items():
        properties[key.replace('_', '-')] = value

def _parse_stream_info(info: str):
    items = info.split('/')
    return StreamInfo(
        originator=items[0],
        template=items[1] if len(items) == 2 else ''
    )

def _get_node_name(func, name) -> str:
    if not hasattr(func, "name_counter"):
        func.name_counter = 0
    else:
        func.name_counter += 1
    base_name = func.__name__.split('.')[-1]
    return f"{base_name}-{name}-{func.name_counter}"

def _validate_uri(uri: str):
    # parse the source uri
    parsed_uri = urlparse(uri)
    if not parsed_uri.scheme or parsed_uri.scheme == 'file':
        if not os.path.exists(parsed_uri.path):
            raise Exception(f"File {parsed_uri.path} doesn't exist")
        if not parsed_uri.scheme:
           uri = f"file://{parsed_uri.path}"
    return uri


class Flow:
    """
    The Flow class for constructing AI streaming flow
    """
    DEFAULT_PICTURE_WIDTH = 1920
    DEFAULT_PICTURE_HEIGHT = 1080
    DEFAULT_SOURCE_TYPE = "nvurisrcbin"
    DYNAMIC_SOURCE_TYPE = "nvdsdynamicsrcbin"
    DEFAULT_BATCH_PUSH_TIMEOUT = 33000

    def __init__(self, pipeline: Pipeline, streams=[], parent=None):
        """
        Initialize a new flow

        Args:
            pipeline(Pipeline): pipeline instance used by the flow
            streams(list[str]): list of stream descriptions
            parent(Flow):       parent flow from which the current flow is generated
        """
        self._pipeline = pipeline
        self._streams = streams
        self._parent = parent
        self._batch_size = parent._batch_size if parent else 0
        self._sr_controller = None

    def __call__(self, on_message=None):
        """
        Activate the current flow.
        The call will not return until the flow is done
        Args:
            on_message (Callable[Pipeline, PipelineMessage]): message callback, optional
        """
        self._pipeline.start(on_message).wait()

    @property
    def pipeline(self):
        return self._pipeline

    def capture(self, inputs: list, source_manager=None, **kwargs):
        """
        Create a flow to capture a list of inputs, which creates one or more streams for
        any derived flow.

        Args:
            input(list(str)): list of input URIs
            kwargs:           key word argument for the source node
        Return: A derived flow
        Raises: TypeError
        """
        func = Flow.capture
        streams = []
        if source_manager is None:
            if not inputs:
                raise TypeError("No input list provided for capturing")
            # create source bin for each input in the list
            for input in inputs:
                source = _get_node_name(func, 'source')
                source_properties = {"uri": _validate_uri(input)}
                _populate_kwargs(source_properties, **kwargs)
                self._pipeline.add(self.DEFAULT_SOURCE_TYPE, source, source_properties)
                streams.append(f"{source}/vsrc_%u")
        else:
            # create dynamic source bin
            source = _get_node_name(func, 'source')
            source_properties = dict()
            _populate_kwargs(source_properties, **kwargs)
            self._pipeline.add(self.DYNAMIC_SOURCE_TYPE, source, source_properties)
            source_manager.attach("add-source", self._pipeline[source])
            source_manager.attach("remove-source", self._pipeline[source])
            source_manager.attach("terminate", self._pipeline[source])
            for input in inputs:
                source_manager.add_source(input)
            streams.append(source)
        return Flow(self._pipeline, streams=streams, parent=self)

    def batch_capture(self, input, smart_record_config: Optional[SmartRecordConfig] = None, **kwargs):
        """
        Create a flow to capture multiple sources and batch them together

        Args:
            input(list(str) or str): list of URIs or a source config file
            smart_record_config(SmartRecordConfig): configuration for smart record functionality
            **kwargs: width, height, batch-size are supported
        Return: A derived flow
        Raises: TypeError
        """
        func = Flow.batch_capture
        streams = []
        source_config = None
        uri_list = []
        properties = {}
        default_mux_properties = {
            "width": self.DEFAULT_PICTURE_WIDTH,
            "height": self.DEFAULT_PICTURE_HEIGHT,
            "batch-size": 1,
            "batched-push-timeout": self.DEFAULT_BATCH_PUSH_TIMEOUT,
            "buffer-pool-size": 4,
            "drop-pipeline-eos": False,
            "live-source": False,
        }
        default_source_properties = {
            "file-loop": False
        }

        _populate_kwargs(properties, **kwargs)
        gpu_id = properties["gpu-id"] if "gpu-id" in properties else 0
        source = _get_node_name(func, 'source')

        if isinstance(input, list):
            uri_list = input
        elif isinstance(input, str) and os.path.splitext(input)[1] in ['.yaml', '.yml']:
            source_config = SourceConfig()
            source_config.load(input)
            uri_list = [sensor.uri for sensor in source_config.sensor_list]
        else:
            raise TypeError("input must be a source list or source config file")

        if len(uri_list) > 0:
            # default batch size is the number of sources
            default_mux_properties["batch-size"] = len(uri_list)

        if source_config and source_config.source_type == "nvmultiurisrcbin":
            source_properties = dict(source_config.source_properties)
            default_properties = default_source_properties | default_mux_properties
            for k, v in default_properties.items():
                if k in properties:
                    # override the source config properties
                    source_properties[k] = properties[k]
                elif not k in source_properties:
                    # use the default value
                    source_properties[k] = v
            batch_size = source_properties.pop("batch-size")
            if not "max-batch-size" in source_properties:
                source_properties["max-batch-size"] = batch_size
            source_properties["uri-list"] = ','.join([source.uri for source in source_config.sensor_list])
            source_properties["sensor-id-list"] = ','.join([source.sensor_id for source in source_config.sensor_list])
            source_properties["sensor-name-list"] = ','.join([source.sensor_name for source in source_config.sensor_list])
            self._pipeline.add("nvmultiurisrcbin", source, source_properties)
            streams.append(source)
            self._batch_size = source_properties["max-batch-size"]
        else:
            streammux_properties = {}
            for k, v in default_mux_properties.items():
                if k in properties:
                    # override the source config properties
                    streammux_properties[k] = properties[k]
                else:
                    # use the default value
                    streammux_properties[k] = v
            mux = _get_node_name(func, 'mux')
            self._pipeline.add("nvstreammux", mux, streammux_properties)
            if smart_record_config:
                self._sr_controller = CommonFactory.create("smart_recording_action", "sr_controller")
                if isinstance(self._sr_controller, signal.Emitter):
                    sr_controller_properties = {
                        "proto-lib": smart_record_config.proto_lib,
                        "conn-str": smart_record_config.conn_str,
                        "msgconv-config-file": smart_record_config.msgconv_config_file,
                        "proto-config-file": smart_record_config.proto_config_file,
                        "topic-list": smart_record_config.topic_list
                    }
                    self._sr_controller.set(sr_controller_properties)
                else:
                    raise ValueError("Failed to create smart recording controller")
            for i, uri in enumerate(uri_list):
                if smart_record_config:
                    source_properties = {
                        "uri": _validate_uri(uri),
                        "gpu-id": gpu_id,
                        "smart-record": 1,
                        "smart-rec-cache": smart_record_config.smart_rec_cache,
                        "smart-rec-container": smart_record_config.smart_rec_container,
                        "smart-rec-dir-path": smart_record_config.smart_rec_dir_path,
                        "smart-rec-mode": smart_record_config.smart_rec_mode,
                    }
                else:
                    source_properties = {
                        "uri": _validate_uri(uri),
                        "gpu-id": gpu_id
                    }
                source_name = f"{source}_{i}"
                source_type = source_config.source_type if source_config else self.DEFAULT_SOURCE_TYPE
                for k, v in default_source_properties.items():
                    if k in properties:
                        # override the source config properties
                        source_properties[k] = properties[k]
                    elif source_config and k in source_config.source_properties:
                        # use the source config properties
                        source_properties[k] = source_config.source_properties[k]
                    else:
                        # use the default value
                        source_properties[k] = v
                self._pipeline.add(source_type, source_name, source_properties).link((source_name, mux), ("vsrc_%u", ""))
                if smart_record_config:
                    self._sr_controller.attach("start-sr", self._pipeline[source_name])
                    self._sr_controller.attach("stop-sr", self._pipeline[source_name])
                    self._pipeline.attach(source_name, "smart_recording_signal", "sr", "sr-done")
            streams.append(mux)
            self._batch_size = len(uri_list)

        return Flow(self._pipeline, streams=streams, parent=self)

    def inject(self, providers: list, **kwargs):
        """
        Inject raw data to the pipeline by creating buffers
        Supported format:
            raw:     ["RGB", "RGBA", "I420"]
            encoded: ["JPEG"]
        Args:
            provider(list(BufferProvider)): list of providers, width/height/format/framerate/device must be supplied
        Return: A derived flow
        Raises: TypeError
        """
        if not providers:
            raise TypeError("List of providers must be supplied for injecting data")
        streams = []
        for provider in providers:
            if provider.format.upper() not in _mime_table:
                raise Exception(f"Format {provider.format} not supported")
            mime = _mime_table[provider.format.upper()]
            raw_data = True if provider.format in ["RGB", "RGBA", "I420"] else False
            if mime == "video/x-raw" and hasattr(provider, "device") and 'gpu' in provider.device:
                mime += "(memory:NVMM)"
            source = _get_node_name(Flow.inject, "source")
            converter = _get_node_name(Flow.inject, "converter")
            capsfilter = _get_node_name(Flow.inject, "capsfilter")
            feeder = _get_node_name(Flow.inject, "feeder")
            caps1 = f"{mime}, format={provider.format}, width={provider.width}, height={provider.height}, framerate={provider.framerate}/1"
            caps2 = f"video/x-raw(memory:NVMM), format=NV12, width={provider.width}, height={provider.height}, framerate={provider.framerate}/1"
            self._pipeline.add("appsrc", source, {
                "caps": caps1,
                "do-timestamp": True
            }).attach(source, Feeder(feeder, provider), tips="need-data/enough-data")
            if raw_data:
                self._pipeline.add("nvvideoconvert", converter,  {"gpu-id": kwargs.pop("gpu_id", 0)})
                self._pipeline.add("capsfilter", capsfilter, {"caps": caps2})
                self._pipeline.link(source, converter, capsfilter)
                streams.append(capsfilter)
            else:
                streams.append(source)

        return Flow(self._pipeline, streams=streams, parent=self)


    def retrieve(self, retriever: BufferRetriever, **kwargs):
        """
        Retrieve the buffer from the pipeline.
        If users want to reuse the data in the buffer, it must be
        copied out from the callback, otherwise it'll be disposed
        by the pipeline.
        Args:
            retriever(BufferRetriever): retriever object to pull the data
        Return: A derived flow
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        stream_info = _parse_stream_info(self._streams[0])
        converter = _get_node_name(Flow.retrieve, "converter")
        capsfilter = _get_node_name(Flow.retrieve, "capsfilter")
        sink = _get_node_name(Flow.retrieve, "appsink")
        receiver = _get_node_name(Flow.retrieve, "receiver")
        gpu_id = kwargs.pop("gpu_id", 0)
        sink_properties = {"emit-signals": True, "sync": False}
        _populate_kwargs(sink_properties, **kwargs)
        self._pipeline.add("nvvideoconvert", converter, {"gpu-id": gpu_id, "compute-hw": 1 if platform.processor() == 'aarch64' else 0,})
        self._pipeline.add("appsink", sink, sink_properties).attach(sink, Receiver(receiver, retriever), tips="new-sample")
        self._pipeline.add("capsfilter", capsfilter, {"caps": "video/x-raw(memory:NVMM), format=RGB"})
        self._pipeline.link(converter, capsfilter, sink)
        if stream_info.template:
             self._pipeline.link(
                 (stream_info.originator, converter),
                 (stream_info.template, '')
             )
        else:
            self._pipeline.link(stream_info.originator, converter)
        return Flow(self._pipeline, parent=self)

    def batch(self, **kwargs):
        """
        Create a batch for buffers received from each upstream.
        By default, the batch size will be set to the number of upstreams
        Args:
            kwargs: overriding streammux properties(use in caution)
        Return: A derived flow
        Raises: Upstream Exception
        """
        #set the batch size
        if len(self._streams) == 0:
            raise Exception("Upstream error: no stream found")
        if self._batch_size != 0:
            raise Exception("Upstream error: already batched")

        # populate the properties from kwargs
        properties = {}
        _populate_kwargs(properties, **kwargs)
        if "batch-size" not in properties:
            properties["batch-size"] = len(self._streams)
        self._batch_size = properties["batch-size"]
        if "width" not in properties:
            properties["width"] = self.DEFAULT_PICTURE_WIDTH
        if "height" not in properties:
            properties["height"] = self.DEFAULT_PICTURE_HEIGHT

        mux_name = _get_node_name(Flow.batch, "mux")
        self._pipeline.add("nvstreammux", mux_name, properties)

        for stream in self._streams:
            stream_info = _parse_stream_info(stream)
            self._pipeline.link(
                (stream_info.originator, mux_name),
                (stream_info.template, "sink_%u")
            )

        return Flow(self._pipeline, streams=[mux_name], parent=self)

    def decode(self, **kwargs):
        """
        Add decoders to the pipeline
        Return: A derived flow
        """
        streams = []
        for i, stream in enumerate(self._streams):
            converter_name = _get_node_name(Flow.decode, "converter")
            decoder_name = _get_node_name(Flow.decode, "decode")
            properties = {}
            _populate_kwargs(properties, **kwargs)
            gpu_id = properties["gpu-id"] if "gpu-id" in properties else 0
            self._pipeline.add("decodebin", decoder_name, properties)
            self._pipeline.add("nvvideoconvert", converter_name, {"gpu-id": gpu_id})
            self._pipeline.link(stream, decoder_name, converter_name)
            streams.append(f"{converter_name}")

        return Flow(self._pipeline, streams=streams, parent=self)

    def infer(self, config, with_triton=False, **kwargs):
        """
        Enable inference in the pipeline
        Args:
            config: the inference configuration
            kwargs: for overriding inference configuration(use in caution)
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")

        config_file_path = None
        if not isinstance(config, str):
            raise TypeError("Inference config must be a file path")
        elif os.path.exists(config):
            config_file_path = config
        element_name = "nvinferserver" if with_triton else "nvinfer"
        infer_name = _get_node_name(Flow.infer, "infer")
        properties = {"config-file-path": config_file_path} if config_file_path else {}
        _populate_kwargs(properties, **kwargs)
        if not "batch-size" in properties:
            properties["batch-size"] = self._batch_size
        self._pipeline.add(element_name, infer_name, properties)

        self._pipeline.link(self._streams[0], infer_name)

        return Flow(self._pipeline, streams=[infer_name], parent=self)

    def analyze(self, config, **kwargs):
        """
        Enable analytics in the pipeline
        Args:
            kwargs: standard analytics properties
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        analytics = _get_node_name(Flow.analyze, "analyze")
        if not os.path.exists(config):
            raise FileNotFoundError(f"Config file {config} not found")
        properties = {"config-file": config}
        _populate_kwargs(properties, **kwargs)
        self._pipeline.add("nvdsanalytics", analytics, properties)
        self._pipeline.link(self._streams[0], analytics)
        return Flow(self._pipeline, streams=[analytics], parent=self)

    def track(self, **kwargs):
        """
        Track the detected object, must come after primary inference
        Args:
            kwargs: standard tracker properties
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        tracker = _get_node_name(Flow.track, "tracker")
        properties = {}
        _populate_kwargs(properties, **kwargs)
        self._pipeline.add("nvtrackerbin", tracker, properties)
        self._pipeline.link(self._streams[0], tracker)
        return Flow(self._pipeline, streams=[tracker], parent=self)

    def render(self, mode: RenderMode = RenderMode.DISPLAY, enable_osd = True, rtsp_mount_point: str = 'ds-test5', rtsp_port: int = 8554, **kwargs):
        """
        Render the video buffers on a display
        Args:
            mode:   renderer mode, DISCARD for dropping output
            enable_osd: enable Overlay Display
            rtsp_mount_point: rtsp mount point
            rtsp_port: rtsp port
            kwargs: standard sink parameter with kwargs
        Return: A derived flow
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")

        properties = {}
        _populate_kwargs(properties, **kwargs)
        stream_info = _parse_stream_info(self._streams[0])
        gpu_id = properties["gpu-id"] if "gpu-id" in properties else 0
        sink_name = _get_node_name(Flow.render, "sink")
        tiler_name = _get_node_name(Flow.render, "tiler")
        converter_name = _get_node_name(Flow.render, "convert")
        osd_name = _get_node_name(Flow.render, "osd")
        if mode == RenderMode.DISCARD:
            self._pipeline.add("fakesink", sink_name, properties)
            if stream_info.template:
                self._pipeline.link(
                    (stream_info.originator, sink_name),
                    (stream_info.template, '')
                )
            else:
                self._pipeline.link(stream_info.originator, sink_name)
        elif mode == RenderMode.DISPLAY or RenderMode.STREAM:
            sink_type = 'nv3dsink' if platform.processor() == 'aarch64' else 'nveglglessink'

            self._pipeline.add("nvvideoconvert", converter_name, {"gpu-id": gpu_id})
            if stream_info.template:
                self._pipeline.link(
                    (stream_info.originator, converter_name),
                    (stream_info.template, '')
                )
            else:
                self._pipeline.link(stream_info.originator, converter_name)
            last_name = converter_name
            if self._batch_size > 1:
                tiler_properties = {
                    "gpu-id": gpu_id,
                    "width": properties.pop("width", self.DEFAULT_PICTURE_WIDTH),
                    "height": properties.pop("height", self.DEFAULT_PICTURE_HEIGHT)
                }
                self._pipeline.add("nvmultistreamtiler", tiler_name, tiler_properties)
                self._pipeline.link(last_name, tiler_name)
                last_name = tiler_name
            if enable_osd:
                self._pipeline.add("nvdsosd", osd_name, {"gpu-id": gpu_id})
                self._pipeline.link(last_name, osd_name)
                last_name = osd_name

            if mode == RenderMode.STREAM:
                sink_type = 'nvrtspoutsinkbin'
                properties = {
                    "rtsp-port": rtsp_port,
                    "rtsp-mount-point": rtsp_mount_point,
                    "sync": False if "sync" not in kwargs else kwargs["sync"],
                    "async": False
                }

            self._pipeline.add(sink_type, sink_name, properties).link(last_name, sink_name)
        else:
            raise ValueError("Invalid render mode")

        return Flow(self._pipeline, parent=self)

    def attach(self, what, name="", tips="", properties=None):
        """
        Attach a probe to the current flow
        Args:
            what:       object or name of the module that creates an object
            name:       name of the object, not applicable for explicitly created object
            tips (str): extra information for the custom object
            properties (Dict): properties to be set on the object, not applicable for explicitly created object
        Return: A derived flow
        """
        for stream in self._streams:
            stream_info = _parse_stream_info(stream)
            if not tips:
                tips = stream_info.template
            self._pipeline.attach(stream_info.originator, what, name, tips, properties)
        return Flow(self._pipeline, streams=self._streams, parent=self)

    def fork(self):
        """
        Fork a flow to support multiple processing branches
        Args: None
        Return: A derived flow
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        tee = _get_node_name(Flow.fork, "tee")
        stream_info = _parse_stream_info(self._streams[0])
        self._pipeline.add("tee", tee).link(
            (stream_info.originator, tee),
            (stream_info.template, "")
        )
        return Flow(self._pipeline, [tee], parent=self)

    def publish(self, **kwargs):
        """
        Publish generated events to a remote server
        Args:
            kwargs: standard nvmsgconv/nvmsgbroker properties
        Return: A derived flow
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        sink = _get_node_name(Flow.publish, "msgsink")
        stream_info = _parse_stream_info(self._streams[0])
        sink_properties = { "sync": False }
        _populate_kwargs(sink_properties, **kwargs)
        self._pipeline.add("nvmsgbrokersinkbin", sink, sink_properties).link(
            (stream_info.originator, sink),
            (stream_info.template, "")
        )
        return Flow(self._pipeline, parent=self)

    def encode(self, dest: str, use_sw_codec=False, **kwargs):
        """
        Encode the stream to a file or through RTSP streaming
        Args:
            dest(str): support "file://" and "udp://"
            use_sw_code: flag for switching to software codec
            kwargs: encoding options: profile/bitrate/iframeinterval/codec_type
                    sink options: sync
        Return: A derived flow
        Raises: Upstream Exception
        """
        format_list = ['.MP4', '.MOV', '.JPG', '.MJPG']
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        uri = urlparse(dest)
        to_file = True if not uri.scheme or uri.scheme == "file" else False
        file_ext = os.path.splitext(uri.path)[1] if to_file else ""
        if not to_file and uri.scheme != "udp" and uri.scheme != "rtsp":
            raise TypeError("Only file, rtsp or udp are supported.")
        if to_file and file_ext.upper() not in format_list:
            raise TypeError(f"File extension {file_ext} is not supported")
        if not to_file and uri.hostname and not uri.hostname in ["localhost", "127.0.0.1"]:
            raise TypeError("Only localhost is supported for streaming")

        stream_info = _parse_stream_info(self._streams[0])
        queue = _get_node_name(Flow.encode, "queue")
        converter = _get_node_name(Flow.encode, "convert")
        capsfilter = _get_node_name(Flow.encode, "capsfilter")
        encoder = _get_node_name(Flow.encode, "encoder")
        parser = _get_node_name(Flow.encode, "parser")
        mux = _get_node_name(Flow.encode, "mux")
        sink = _get_node_name(Flow.encode, "filesink")
        mem_type = "video/x-raw" if use_sw_codec else "video/x-raw(memory:NVMM)"
        capsfilter_properties = { "caps": f"{mem_type}, format=I420"}
        encoder_properties = {
            "profile":  kwargs["profile"] if "profile" in kwargs else 0,
            "iframeinterval":  kwargs["iframeinterval"] if "iframeinterval" in kwargs else 10,
            "bitrate": kwargs["bitrate"] if "bitrate" in kwargs else 2000000,
        }
        converter_properties = {"gpu-id": kwargs["gpu_id"] if "gpu_id" in kwargs else 0}
        file_sink_properties = { "location": uri.path, "sync": False if "sync" not in kwargs else kwargs["sync"], "async": False }
        rtsp_sink_properties = { "rtsp-port": uri.port, "sync": False if "sync" not in kwargs else kwargs["sync"], "async": False }
        udp_sink_properties = { "host": "127.0.0.1", "port": uri.port, "sync": False if "sync" not in kwargs else kwargs["sync"], "async": False }
        if uri.scheme == "rtsp":
            self._pipeline.add("queue", queue).add("nvvideoconvert", converter, converter_properties).add("nvrtspoutsinkbin", sink, rtsp_sink_properties).link(
                (stream_info.originator, queue),
                (stream_info.template, "")
            ).link(queue, converter, sink)
        elif file_ext.upper() in ['.JPG', '.MJPG']:
            # JPEG encoder:
            codec = "jpegenc" if use_sw_codec else "nvjpegenc"
            self._pipeline.add("queue", queue).add("nvvideoconvert", converter, converter_properties)
            self._pipeline.add("capsfilter", capsfilter, capsfilter_properties)
            self._pipeline.add(codec, encoder, encoder_properties)
            self._pipeline.add("filesink", sink, file_sink_properties)
            self._pipeline.link(
                (stream_info.originator, queue),
                (stream_info.template, "")
            ).link(queue, converter, capsfilter, encoder, sink)
        else:
            self._pipeline.add("queue", queue).add("nvvideoconvert", converter, converter_properties)
            self._pipeline.add("capsfilter", capsfilter, capsfilter_properties)
            codec_type = kwargs.get("codec_type", "h264").lower()
            match codec_type:
                case "h264":
                    codec = "x264enc" if use_sw_codec else "nvv4l2h264enc"
                    self._pipeline.add(codec, encoder, encoder_properties).add("h264parse", parser)
                case "h265":
                    codec = "x265enc" if use_sw_codec else "nvv4l2h265enc"
                    self._pipeline.add(codec, encoder, encoder_properties).add("h265parse", parser)
                case "av1":
                    codec = "av1enc" if use_sw_codec else "nvv4l2av1enc"
                    self._pipeline.add(codec, encoder, encoder_properties).add("av1parse", parser)
                case _:
                    raise TypeError(f"Codec type {codec_type} is not supported")
            if to_file:
                self._pipeline.add("mp4mux", mux).add("filesink", sink, file_sink_properties)
            else:
                self._pipeline[parser].set({"config-interval": -1})
                match codec_type:
                    case "h264":
                        self._pipeline.add("rtph264pay", mux)
                    case "h265":
                        self._pipeline.add("rtph265pay", mux)
                    case "av1":
                        # rtpav1pay and rtpav1depay plugins provided by gst-plugins-rs
                        self._pipeline.add("rtpav1pay", mux)
                self._pipeline.add("udpsink", sink, udp_sink_properties)

            self._pipeline.link(
                (stream_info.originator, queue),
                (stream_info.template, "")
            ).link(queue, converter, capsfilter, encoder, parser, mux, sink)

        return Flow(self._pipeline, parent=self)

    def preprocess(self, config_file: str, tensor_generator: Callable[[None], dict[str, Tensor]]=None, **kwargs):
        """
        Preprocess the stream
        """
        class TensorGenerator(BatchMetadataOperator):
            def __init__(self, tensor_generator: Callable[[int], dict[str, Tensor]]=None, target_unique_id: int=1):
                super().__init__()
                self._tensor_generator = tensor_generator
                self._target_unique_id = target_unique_id

            def handle_metadata(self, batch_meta):
                tensors = self._tensor_generator(batch_meta.n_frames)
                for name, tensor in tensors.items():
                    tensor_batch = batch_meta.acquire_preprocess_batch_meta()
                    tensor_batch.set_preprocessed_tensor(name, 0, self._target_unique_id, tensor)
                    batch_meta.append(tensor_batch)

        if not os.path.exists(config_file):
            raise FileNotFoundError(f"Config file {config_file} not found")
        properties = { 'config-file': config_file, 'target-unique-ids': 1 }
        _populate_kwargs(properties, **kwargs)
        preprocess_name = _get_node_name(Flow.preprocess, "preprocess")
        queue_name = _get_node_name(Flow.preprocess, "queue")
        self._pipeline.add("nvdspreprocess", preprocess_name, properties).add("queue", queue_name)
        if tensor_generator:
            probe = Probe("probe", TensorGenerator(tensor_generator, properties["target-unique-ids"]))
            self._pipeline.attach(preprocess_name, probe)
        self._pipeline.link(self._streams[0], preprocess_name).link(preprocess_name, queue_name)
        return Flow(self._pipeline, streams=[queue_name], parent=self)

