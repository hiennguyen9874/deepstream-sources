#
# SPDX-FileCopyrightText: Copyright (c) 2024-2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

import yaml
from collections import namedtuple
from dataclasses import dataclass

SensorInfo = namedtuple("SensorInfo", ["sensor_id", "sensor_name", "uri"])
CameraInfo = namedtuple("CameraInfo", ["camera_type", "camera_video_format", "camera_width", "camera_height", "camera_fps_n", "camera_fps_d",
                                       "camera_csi_sensor_id", "camera_v4l2_dev_node", "gpu_id", "nvbuf_mem_type",
                                       "nvvideoconvert_copy_hw"])

class SourceConfig:
    """Class for parsing source configuration"""
    def __init__(self):
        self._sensor_list = []
        self._camera_list = []
        self._source_type = None
        self._source_properties = dict()

    @property
    def sensor_list(self):
        return self._sensor_list

    @property
    def camera_list(self):
        return self._camera_list

    @property
    def source_type(self):
        return self._source_type

    @property
    def source_properties(self):
        return self._source_properties

    def load(self, config_file: str):
        """Load source configurations from a YAML file"""
        with open(config_file, 'r') as file:
            doc = yaml.safe_load(file)
            if doc:
                source_list = doc.get("source-list")
                camera_list = doc.get("camera-list")
                source_config = doc.get("source-config")
                if source_list is not None:
                    for source in source_list:
                        uri = source.get("uri")
                        sensor_id = source.get("sensor-id")
                        sensor_name = source.get("sensor-name")
                        self._sensor_list.append(SensorInfo(sensor_id, sensor_name, uri))
                if camera_list is not None:
                    for camera in camera_list:
                        camera_type = camera.get("camera-type")
                        camera_video_format = camera.get("camera-video-format")
                        camera_width = camera.get("camera-width")
                        camera_height = camera.get("camera-height")
                        camera_fps_n = camera.get("camera-fps-n")
                        camera_fps_d = camera.get("camera-fps-d")
                        camera_csi_sensor_id = camera.get("camera-csi-sensor-id")
                        camera_v4l2_dev_node = camera.get("camera-v4l2-dev-node")
                        gpu_id = camera.get("gpu-id")
                        nvbuf_mem_type = camera.get("nvbuf-mem-type")
                        nvvideoconvert_copy_hw = camera.get("nvvideoconvert-copy-hw")
                        self._camera_list.append(CameraInfo(camera_type, camera_video_format, camera_width, camera_height, camera_fps_n, camera_fps_d,
                                                            camera_csi_sensor_id, camera_v4l2_dev_node, gpu_id, nvbuf_mem_type,
                                                            nvvideoconvert_copy_hw))
                if source_config:
                    self._source_type = source_config.get("source-bin")
                    self._source_properties = source_config.get("properties")
                if camera_list is not None and len(camera_list):
                    self._source_type = "camerabin"


@dataclass
class SmartRecordConfig:
    """Configuration for smart recording functionality in DeepStream pipeline.
    
    Smart recording allows for intelligent recording of video streams based on events
    or specific conditions. This configuration class encapsulates all the necessary
    parameters for setting up smart recording in a DeepStream pipeline.

    Required Parameters:
        proto_lib (str): Path to the protocol library (e.g., Kafka protocol library)
        conn_str (str): Connection string for the message broker (e.g., "localhost;9092")
        msgconv_config_file (str): Path to the message converter configuration file
        proto_config_file (str): Path to the protocol configuration file
        topic_list (str): Comma-separated list of topics for message publishing

    Optional Parameters:
        smart_rec_cache (int): Size of cache in seconds, applies to both audio and video cache.
            Range: 0 - 4294967295. Default: 20
        smart_rec_container (int): Container format of recorded video. MP4 and MKV containers are supported.
            Sources must be of type source-type-rtsp.
            Default: 0 (MP4 container)
        smart_rec_dir_path (str): Path of directory to save the recorded file.
            Default: "."
        smart_rec_mode (int): Smart record mode.
            0: Record both audio and video if available
            1: Record video only if available
            2: Record audio only if available
            Default: 0

    Example:
        config = SmartRecordConfig(
            proto_lib="/path/to/libnvds_kafka_proto.so",
            conn_str="localhost;9092",
            msgconv_config_file="/path/to/msgconv_config.txt",
            proto_config_file="/path/to/proto_config.txt",
            topic_list="sr-test",
            smart_rec_cache=30
        )
    """
    proto_lib: str
    conn_str: str
    msgconv_config_file: str
    proto_config_file: str
    topic_list: str
    smart_rec_cache: int = 20
    smart_rec_container: int = 0
    smart_rec_dir_path: str = "."
    smart_rec_mode: int = 0